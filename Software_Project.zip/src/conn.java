import java.sql.*;

public class conn
{
    Connection c;
    Statement s;
    public conn()
    {
        String sql;
        try
        {
           // Class.forName("com.mysql.jdbc.Driver");
            //c=DriverManager.getConnection("jdbc:mysql://localhost/ebs","root","password");
            //s=c.createStatement();
            String driver="oracle.jdbc.OracleDriver";
            String jdbc_url="jdbc:oracle:thin:@localhost:1521:XE";
            String user="system";
            String pwd="THEJA2004";
            Class.forName(driver);
             c=DriverManager.getConnection(jdbc_url,user,pwd);
             s=c.createStatement();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

    }

    public CallableStatement prepareCall(String sql) throws SQLException {

        return c.prepareCall(sql);
    }
}
