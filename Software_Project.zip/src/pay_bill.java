import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.URI;

public class pay_bill extends JFrame {
    pay_bill() {
        JButton openPaytmButton = new JButton("Open Paytm Website");
        openPaytmButton.addActionListener(e -> openPaytmWebsite());

        JPanel panel = new JPanel();
        panel.add(openPaytmButton);

        add(panel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 100);
        setLocationRelativeTo(null); // Center the window
        setVisible(true);
    }

    private void openPaytmWebsite() {
        try {
            Desktop.getDesktop().browse(new URI("https://paytm.com/electricity-bill-payment"));
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Could not open Paytm website. Please try again later.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        // Create and show the GUI on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> new pay_bill());
    }
}
